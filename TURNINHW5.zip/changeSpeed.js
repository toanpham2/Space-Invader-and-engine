// This script moves the GameObject with handle "gameobject0" (it's guid)
function changeSpeed(x) {
	var tx = playableRec0.xSpeed + x;
    playableRec0.xSpeed = tx ;
}
changeSpeed(30);


