#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <iostream>
#include <cmath>
#include <chrono>
#include <mutex>
#include <condition_variable>
#include "Platforms.h"
#include <thread>
#include <zmq.hpp>
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>


void EventDeathOffMap :: dummy(){

}

EventDeathOffMap  :: EventDeathOffMap () : Event(){
    setType( "DeadMapLimit");
}




